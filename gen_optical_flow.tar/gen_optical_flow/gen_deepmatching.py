import argparse
import cv2
import os
import glob
import sys
import numpy as np
import errno
import subprocess

import time



def mkdir_if_missing(dir_path):
    try:
        os.makedirs(dir_path)
    except OSError as e:
        if e.errno != errno.EEXIST:
            raise


def cvReadGrayImg(img_path):
    return np.array(cv2.imread(img_path))



def saveOptFlowToImage(flow, basename, merge):
    if merge:
        # save x, y flows to r and g channels
        # Fill third channel with zeros
        h, w = flow[..., 1].shape
        flow = np.concatenate((flow, np.zeros((h, w, 1))), axis=2)
        cv2.imwrite(basename + '.png', flow)

    else:
        cv2.imwrite(basename + '_x.JPEG', flow[..., 0])
        cv2.imwrite(basename + '_y.JPEG', flow[..., 1])


def main(args):
    persons = sorted(glob.glob(os.path.join(args.vid_dir, '*')))
    print("Processing {}: {} files... ".format(args.vid_dir, len(persons)))

    margin = args.margin
    person_len = len(persons)


    for per in range(person_len):
        person_basename = os.path.basename(persons[per])
        images = sorted(glob.glob(os.path.join(persons[per], '*')))
        mkdir_if_missing(os.path.join(args.save_dir, person_basename))
        img_len = len(images)
        tic = time.time()
        for ind, img_path in enumerate(images):

            img = images[ind]
            ref_imgs = []

            if ind + margin < img_len:
                ref_imgs.append(images[ind+margin])
            if ind - margin >= 0:
                ref_imgs.append(images[ind-margin])



            # save
            if not os.path.isdir(args.save_dir):
                os.makedirs(args.save_dir)
            basename = os.path.splitext(os.path.basename(img_path))[0]+'.txt'
            basepath = os.path.join(args.save_dir, person_basename, basename)

            # execution
            bashline = "./deepmatching" + " " + img + " " + ref_imgs[0] + " " + "-png_settings"+ \
                   " " + "-out" + " " + " " + basepath

            process = subprocess.Popen(bashline.split(), stdout=subprocess.PIPE)
            output, error = process.communicate()

        toc = time.time()
    print("{:.2f} min, {:.2f} fps".format((toc-tic) / 60., 1. * len(images) / (toc - tic)))





if __name__ == '__main__':

    parser = argparse.ArgumentParser()
    parser.add_argument('vid_dir')
    parser.add_argument('save_dir')
    parser.add_argument('--margin', type=int,  default=2,  help='margin of frame to compute the boundary.')
    args = parser.parse_args()
    main(args)
