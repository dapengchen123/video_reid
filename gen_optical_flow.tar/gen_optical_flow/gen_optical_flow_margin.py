import argparse
import cv2
import os
import glob
import errno
import sys
import numpy as np


import time


def mkdir_if_missing(dir_path):
    try:
        os.makedirs(dir_path)
    except OSError as e:
        if e.errno != errno.EEXIST:
            raise

def cvReadGrayImg(img_path):
    return cv2.cvtColor(cv2.imread(img_path), cv2.COLOR_BGR2GRAY)



def saveOptFlowToImage(flow, basename, merge):
    if merge:
        # save x, y flows to r and g channels
        # Fill third channel with zeros
        h, w = flow[..., 1].shape
        flow = np.concatenate((flow, np.zeros((h, w, 1))), axis=2)
        cv2.imwrite(basename + '.png', flow)

    else:
        cv2.imwrite(basename + '_x.JPEG', flow[..., 0])
        cv2.imwrite(basename + '_y.JPEG', flow[..., 1])


def main(args):
    persons = sorted(glob.glob(os.path.join(args.vid_dir, '*')))
    print("Processing {}: {} files... ".format(args.vid_dir, len(persons))),

    margin = args.margin
    bound = args.bound
    person_len = len(persons)

    for per in range(person_len):
        person_basename = os.path.basename(persons[per])
        images = sorted(glob.glob(os.path.join(persons[per], '*')))
        mkdir_if_missing(os.path.join(args.save_dir, person_basename))
        img_len = len(images)
        tic = time.time()
        norm_width = 250
        norm_height = 500
        for ind, img_path in enumerate(images):

            img = cvReadGrayImg(images[ind])
            h, w = img.shape
            ref_imgs = []

            if ind - margin >= 0:
                ref_imgs.append(cvReadGrayImg(images[ind-margin]))
            if ind + margin < img_len:
                ref_imgs.append(cvReadGrayImg(images[ind+margin]))

            fx = norm_width/w
            fy = norm_height/h

            flows = []
            len_ref = len(ref_imgs)

            for l in range(len_ref):
                # normalize the image size
                flow = cv2.calcOpticalFlowFarneback(
                    cv2.resize(img, None, fx=fx, fy=fy),
                    cv2.resize(ref_imgs[l], None, fx=fx, fy=fy), None,
                    .5, 6, 4, 3, 2, 0.5, 0)

                # map optical flow back
                flow[..., 0] = flow[..., 0]/fx
                flow[..., 1] = flow[..., 1]/fy
                flows.append(flow)

             # the optical flow
            if len_ref == 2:
                aveflow = (flows[0]-flows[1])/2
            else:
                aveflow = flows[0]

            # normalization
            aveflow = np.round((aveflow + bound) / (2. * bound) * 255.)
            aveflow[aveflow < 0] = 0
            aveflow[aveflow > 255] = 255
            aveflow = cv2.resize(aveflow, (w, h))


            # save
            if not os.path.isdir(args.save_dir):
                os.makedirs(args.save_dir)

            basename = os.path.splitext(os.path.basename(img_path))[0]
            basepath = os.path.join(args.save_dir, person_basename, basename)
            saveOptFlowToImage(aveflow, basepath, args.merge)

            if args.visual_debug:
                mag, ang = cv2.cartToPolar(aveflow[..., 0], aveflow[..., 1])
                hsv = np.zeros_like(cv2.imread(img_path))
                hsv[..., 1] = 255
                hsv[..., 0] = ang * 180 / np.pi / 2
                hsv[..., 2] = cv2.normalize(mag, None, 0, 255, cv2.NORM_MINMAX)
                bgr = cv2.cvtColor(hsv, cv2.COLOR_HSV2BGR)

                cv2.imshow('optical flow', bgr)
                k = cv2.waitKey(30) & 0xff
                if k == 27:
                    break

        toc = time.time()
        print("{:.2f} min, {:.2f} fps".format((toc-tic) / 60., 1. * len(images) / (toc - tic)))




if __name__ == '__main__':

    parser = argparse.ArgumentParser()
    parser.add_argument('vid_dir')
    parser.add_argument('save_dir')
    parser.add_argument('--margin', type=int,  default=2,  help='margin of frame to compute the boundary.')
    parser.add_argument('--bound', type=float, default=5, help='optical flow bounding')
    parser.add_argument('--merge', type=bool, default=True, help='merge of the computed optical flow')
    parser.add_argument('--visual_debug', type=bool, default=False, help='merge of the computed optical flow')
    args = parser.parse_args()
    main(args)